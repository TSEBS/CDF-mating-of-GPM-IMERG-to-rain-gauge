function [ret]=Prob_data(inputx)
ret=(1:length(inputx))./length(inputx+1);
end