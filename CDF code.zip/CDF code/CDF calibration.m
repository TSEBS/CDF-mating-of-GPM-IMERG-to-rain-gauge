%% CDF matching
clc;
clear all;
load hrain0; % Rain gauge, row is the hourly rainfall, colum represent 18 sites
load hrain1; % satellite, row is the hourly rainfall, colum represent 18 sites
Ref_data=hrain0(~isnan(hrain0));        % rain gauge
Biased_data=hrain1(~isnan(hrain1));     % GPM
Prob_ref    = Prob_data(Ref_data)';     % Query points
Prof_biased =  Prob_data(Biased_data)'; % Sample points
Biased_interpolated= interp1(Prof_biased,sort(Biased_data),sort(Prob_ref)); %1-D linear interpolation of GPM-IMERG according to the Rain gauge
% interp1q returns interpolated values of a 1-D function at specific query points using linear interpolation
n=7;     % degree of the polynomial
p= polyfit(Biased_interpolated,sort(Ref_data)-Biased_interpolated, n); % Polynomial fitting between the GPM-IMERG and difference of referenced and interpolated data.
%-------------------------------------------------
[m,n]=size(hrain1)
tp=sort(Ref_data)-Biased_interpolated;
for i=1:m
    for j=1:n
        [~,Id] = min(abs(Biased_interpolated-hrain1(i,j))); %
        Id=median(Id);
        Corrected_Data2(i,j)=tp(Id)+hrain1(i,j);
    end
end
hrain2=Corrected_Data2; % GPM-IMERG-CDF     
%--------------------------------------------------plot result
hd= figure('position',[50 50 500 500]);
%-----------------------------------rain gauge
x=hrain0(~isnan(hrain0));x=sort(x); 
Prob_ref = Prob_data(x)';        %Query points
plot(x,Prob_ref,'k','linewidth',2)
hold on;
%------------------------------------GPM
x=hrain1(~isnan(hrain1));x=sort(x); 
Prob_ref = Prob_data(x)';        %Query points
plot(x,Prob_ref,'b','linewidth',2)
hold on;
%------------------------------------GPM-IMERG-CDF
x=hrain2(~isnan(hrain2));x=sort(x); 
Prob_ref = Prob_data(x)';        %Query points
plot(x,Prob_ref,'r','linewidth',2)
hold on;
xlim([0 6]);
xlabel('1-hr accumulated precipitation [mm/hour]','fontsize',12)
ylabel('CDF','fontsize',12)
legend('Rain gauge','IMERG-F','IMERG-F-CDF')
title('(a)','fontsize',12)
grid on;
%%